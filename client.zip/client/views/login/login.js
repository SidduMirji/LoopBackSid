
/* JavaScript content from views/login/login.js in folder common */

/* JavaScript content from views/login/login.js in folder common */

/* JavaScript content from views/login/login.js in folder common */

/* JavaScript content from views/login/login.js in folder common */

/* JavaScript content from views/login/login.js in folder common */

/* JavaScript content from views/login/login.js in folder common */


app.controller('loginController', function($rootScope, $scope, $state, $ionicLoading, $timeout,$http) {
	
		 
	 
	});

