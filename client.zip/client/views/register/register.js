

app.controller('regController', function($rootScope, $scope, $state, $ionicLoading, $timeout,$http) {

	});

